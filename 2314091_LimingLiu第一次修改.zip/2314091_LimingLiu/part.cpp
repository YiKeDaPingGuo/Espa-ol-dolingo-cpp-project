#include "part.h"

Part::Part()
{

}
