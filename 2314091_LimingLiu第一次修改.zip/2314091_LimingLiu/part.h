#ifndef PART_H
#define PART_H


class Part
{
public:
    Part();
};

#endif // PART_H
