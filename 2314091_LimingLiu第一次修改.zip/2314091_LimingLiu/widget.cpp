#include "widget.h"
#include "worddatabase.h"
#include <QMouseEvent>
#include <QVector2D>
#include <QDebug>
#include <QPushButton>
#include <QMouseEvent>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    setGeometry(100, 100, 540, 960);
    setWindowTitle("Dolingo");
    mGameBackground.load(":/png/png/bkground.png");
    if (mGameBackground.load(":/png/png/bkground.png")) {
        QPalette palette = this->palette();
        palette.setBrush(QPalette::Window, QBrush(mGameBackground.scaled(this->size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation)));
        this->setPalette(palette);
        this->setAutoFillBackground(true);
    } else {
        qDebug() << "Failed to load background image.";
    }

    setMovie(":/gif/gif/Lin-conducir-izquierda.gif",movie,label,360,100,this);
    setMovieButton(":/gif/gif/Lily-celular.gif", Lilymovie, LilyButton, 120, 260);
    setMovieButton(":/gif/gif/Oscar-tender.gif", Oscarmovie, OscarButton, 330, 400);
    setMovieButton(":/gif/gif/Falstaff-comer.gif", Falstaffmovie, FalstaffButton, 200, 500);
    setMovieButton(":/gif/gif/Duo-la-terria.gif", Duomovie, DuoButton, 230, 700);

    if (movie->state() == QMovie::NotRunning) {
        qDebug() << "Failed to load GIF.";
    }

    LinMovetimer = new QTimer(this);

    connect(LinMovetimer, &QTimer::timeout, this, &Widget::moveGif);
    connect(&LilyButton, &QPushButton::clicked, [this]() { onButtonClicked(&LilyButton); });
    connect(&OscarButton, &QPushButton::clicked, [this]() { onButtonClicked(&OscarButton); });
    connect(&FalstaffButton, &QPushButton::clicked, [this]() { onButtonClicked(&FalstaffButton); });
    connect(&DuoButton, &QPushButton::clicked, [this]() { onButtonClicked(&DuoButton); });
}

Widget::~Widget()
{
    delete movie;
    delete Oscarmovie;
    delete Lilymovie;
    delete Falstaffmovie;
    delete Duomovie;
}

void Widget::mousePressEvent(QMouseEvent *event)
{
    int x = event->pos().x() - label.width() / 2;
    int y = event->pos().y() - label.height() / 2;
    targetPos = QPoint(x, y);
    LinMovetimer->start(10); // 启动定时器，每 10 毫秒触发一次
}

void Widget::setMovie(QString filename, QMovie *&m_movie, QLabel &m_label, int x, int y,QWidget * dialog)
{

    m_movie = new QMovie(filename, QByteArray(), dialog);
    m_label.setMovie(m_movie);
    m_label.setFixedSize(108, 108);
    if(m_movie != movie){
        m_label.setFixedSize (250,333);
    }
    m_label.setAlignment(Qt::AlignCenter);
    m_label.setParent(dialog);
    m_label.move(x, y);
    m_label.show();
    m_movie->start();
}

void Widget::setChallengeMovie(QString filename, int x, int y, QWidget* dialog)
{
    // 清理之前的动画
    if (challengeLabel) {
        challengeLabel->deleteLater();
        challengeLabel = nullptr;
    }
    if (challengeMovie) {
        challengeMovie->deleteLater();
        challengeMovie = nullptr;
    }

    // 创建新动画
    challengeLabel = new QLabel(dialog);
    challengeMovie = new QMovie(filename, QByteArray(), dialog);

    challengeLabel->setMovie(challengeMovie);
    challengeLabel->setFixedSize(250, 333);
    challengeLabel->setAlignment(Qt::AlignCenter);
    challengeLabel->move(x, y);
    challengeLabel->show();
    challengeMovie->start();
}


void Widget::setMovieButton(QString filename, QMovie *&m_movie, QPushButton &m_Button, int x, int y)
{
    m_movie = new QMovie(filename, QByteArray(), this);
    m_Button.setFixedSize(108, 108);
    m_Button.setStyleSheet("border: none;");
    m_Button.setParent(this);
    m_Button.move(x, y);
    m_Button.show();

    QLabel *buttonLabel = new QLabel(&m_Button);
    buttonLabel->setMovie(m_movie);
    buttonLabel->setAlignment(Qt::AlignCenter);
    buttonLabel->setFixedSize(108, 108);
    buttonLabel->show();

    m_movie->start();
}

void Widget::ChallengeOne() {
    if (lilyChallengeDialog) {
        isHandlingEventsInMainWidget = false;
        m_currentQuestionIndex1 = 0;
        m_answerResults1.clear();
        m_allChoiceAnswers1.clear();
        dialogOneFront();
        QTimer::singleShot(500, [this]() {
            // 恢复等待动画
            setChallengeMovie(":/gif/gif/LilyEsperar.gif", 0, 50, lilyChallengeDialog);
            qDebug() << "第一段对话结束。";
        });
        QTimer::singleShot(500, [this]() {
            //休息0.5秒

        });
        WordDatabase db;
        for (int j = 1;j<=12;j++) {
            QList<QStringList> records = db.findWithRandomRecords (":/csv/neutral.csv","id",QString::number(j));
            if(records.size()>3){
                m_allChoiceAnswers1.append(records);
            }
        };

        //开始第一题答题
        showLilyNextQuestion();
    }
}

void Widget::setSentence(QString sentence, QWidget *dialog,int x,int y)
{
    if(dialog == lilyChallengeDialog){
        setChallengeMovie(":/gif/gif/LilyHablar.gif", 0, 50, dialog);
    }else if(dialog == oscarChallengeDialog){
        setChallengeMovie(":/gif/gif/OscarHablar.gif", 0, 50, dialog);
    }else if(dialog == falstaffChallengeDialog){
        setChallengeMovie(":/gif/gif/FalstaffHablar.gif", 0, 50, dialog);
    }

    // 清理之前的句子（如果有）
    if (currentSentenceLabel) {
        currentSentenceLabel->deleteLater();
        currentSentenceLabel = nullptr;
    }
    qDebug()<<sentence;

    // 创建新标签（原实现）

    currentSentenceLabel = new QLabel(dialog);
    QFont font = QFontDatabase::systemFont(QFontDatabase::GeneralFont);
    font.setFamily("Arial"); // Arial 是一个支持多种字符的常见字体，你也可以尝试其他字体，如 "Tahoma" 等
    font.setPointSize(12);

    QTextCodec *codec = QTextCodec::codecForName("UTF-8");
    QByteArray utf8Data = codec->fromUnicode(sentence);
    QString utf8Sentence = codec->toUnicode(utf8Data);

    currentSentenceLabel->setFont(font);
    currentSentenceLabel->setText(sentence);
    currentSentenceLabel->setWordWrap(true);
    currentSentenceLabel->setFixedWidth(250);
    currentSentenceLabel->adjustSize();
    currentSentenceLabel->setFixedHeight(currentSentenceLabel->height());
    currentSentenceLabel->move(x, y);
    currentSentenceLabel->show();
}

void Widget::setButton(QString sentence, QWidget *dialog, int x, int y, int length, int width, std::function<void()> onClicked)
{
    QTimer::singleShot(1000, [=]() {
        QPushButton* btn = new QPushButton(sentence, dialog);
        btn->setFont(QFont("Arial", 15));

        btn->setStyleSheet(
                    "QPushButton {"
                    "   background-color: rgb(242, 245, 175);"  // 指定背景颜色
                    "   border: none;"                          // 移除边框
                    "   white-space: pre-wrap;"                // 允许自动换行
                    "   text-align: center;"                    // 文字水平居中
                    "   padding: 10px;"                         // 增加内边距
                    "}"
            );

        // 计算文本高度
        QFontMetrics metrics(btn->font());
        int textHeight = metrics.boundingRect(QRect(0, 0, length, 0), Qt::TextWordWrap, sentence).height();
        btn->setFixedSize(length, qMax(width, textHeight + 10));

        btn->move(x, y);
        btn->show();

        connect(btn, &QPushButton::clicked, [=]() {
            QTimer::singleShot(500, [=]() {
                // 删除当前句子和按钮
                if (currentSentenceLabel) currentSentenceLabel->deleteLater();
                if (btn) btn->deleteLater();
                currentSentenceLabel = nullptr;

                // 执行回调函数（触发下一段对话）
                if (onClicked) onClicked();
            });
        });
    });
}

void Widget::dialogOneFront()
{
    // 第一段对话
    setChallengeMovie(":/gif/gif/LilyEsperar.gif", 0, 50, lilyChallengeDialog);
    setSentence("Well,Lin. Want to learn some spanish?", lilyChallengeDialog, 250, 80);
    setButton("¡Sí!I want.", lilyChallengeDialog, 70, 700, 400, 150, [this]() {
        // 按钮点击后执行的回调
        QTimer::singleShot(500, [this]() {
            // 恢复等待动画
            setChallengeMovie(":/gif/gif/LilyEsperar.gif", 0, 50, lilyChallengeDialog);
            // 显示第二段对话
            setSentence("Mmm……Good for you, although it is hard.", lilyChallengeDialog, 250, 80);
            setButton("Haha, let's do it!", lilyChallengeDialog, 70, 700, 400, 150, [this]() {
                QTimer::singleShot(500, [this]() {
                    // 恢复等待动画
                    setChallengeMovie(":/gif/gif/LilyEsperar.gif", 0, 50, lilyChallengeDialog);
                    qDebug() << "第一段对话结束。";
                });
            });
        });
    });
}

void Widget::checkChoiceButton(QList<QStringList>& records) {
    QStringList filenames;

    // 提取图片路径（带验证）
    for (int i = 0; i < 4; ++i) {
        int baseIndex = i+m_currentQuestionIndex1*4;
        if (baseIndex < records.size()) {
            filenames.append(records[baseIndex][3]);
        }
    }

    // 验证是否获取到4个选项
    if (filenames.size() != 4) {
        qWarning() << "Failed to get 4 choices";
        return;
    }

    // 记录当前题目的正确答案
    m_currentChoices.append(filenames.first ());

    // 创建按钮（带布局验证）
    QList<QPoint> positions = {
        QPoint(15, 350), QPoint(270, 350),
        QPoint(15, 605), QPoint(270, 605)
    };

    int randomNumber = QRandomGenerator::global()->bounded(4);
    int setpic;

    for (int i = randomNumber; i < 4+randomNumber; ++i) {
        if (i >= randomNumber+positions.size()) break;

        setpic = i%4;//随机打乱正确答案位置

        QPushButton* btn = new QPushButton(lilyChallengeDialog);
        // 设置按钮图标（带资源存在性检查）
        if (QFile::exists(filenames[setpic])) {
            QPixmap pix(filenames[setpic]);
            btn->setIcon(pix.scaled(255, 255, Qt::KeepAspectRatio));
        } else {
            btn->setText("Image Missing");
        }
        btn->move(positions[i-randomNumber]);
        connect(btn, &QPushButton::clicked, [this, setpic]() {
            handleAnswerSelection(setpic);
        });
    }
}

void Widget::handleAnswerSelection(int index) {
    // 获取当前题目的正确答案
    QString correctPath = m_currentChoices[1];

    // 验证选择结果
    bool isCorrect = (m_allChoiceAnswers1[4*m_currentQuestionIndex1+index][1] == correctPath);

    // 记录结果
    m_answerResults1.append(isCorrect);

    // 显示动画反馈
    QString animationPath = isCorrect ?
        ":/gif/gif/LilyCorrrecto.gif" :
        ":/gif/gif/LilyCulpa.gif";
    setChallengeMovie(animationPath, 0, 50, lilyChallengeDialog);

    // 1.5秒后进入下一题
    QTimer::singleShot(1500, [this]() {
        m_currentQuestionIndex1++;
        showLilyNextQuestion();
    });
}

void Widget::checkAnswer(int index, QWidget* dialog, std::function<void()> onClicked) {
    // 判断是否选择了正确答案（第一个按钮）
    if (index == 0) {
        setChallengeMovie(":/gif/gif/LilyCorrrecto.gif", 0, 50, dialog);
    } else {
        setChallengeMovie(":/gif/gif/LilyCulpa.gif", 0, 50, dialog);
    }

    // 执行回调（例如关闭对话框或更新分数）
    if (onClicked) onClicked();
}

void Widget::showLilyNextQuestion()
{
    //1. 先清理所有旧的按钮
    qDeleteAll(lilyChallengeDialog->findChildren<QPushButton*>());

    if(m_currentQuestionIndex1>=12){
        checkLilyFinalResult();
        return;
    }
    m_currentChoices = m_allChoiceAnswers1[4*m_currentQuestionIndex1];
    setSentence (m_currentChoices[1],lilyChallengeDialog,250,80);

    if(m_currentChoices.size() >3){
        checkChoiceButton(m_allChoiceAnswers1);
    }
}

void Widget::checkLilyFinalResult()
{
    if (!m_answerResults1.empty() && std::all_of(m_answerResults1.begin(), m_answerResults1.end(), [](bool val) { return val; })) {
        setButton ("Have done the part!", lilyChallengeDialog, 70, 700, 400, 150, [this]() {
            QTimer::singleShot(500, [this]() {
                if (lilyChallengeDialog) {
                    isLilyDone = true;
                    lilyChallengeDialog->close();
                    onLilyDialogClosed();
                }
            });
        });
    }else{
        setButton ("Try again!", lilyChallengeDialog, 70, 700, 400, 150, [this]() {
            QTimer::singleShot(500, [this]() {
                if (lilyChallengeDialog) {
                    isLilyDone = false;
                    lilyChallengeDialog->close();
                    onLilyDialogClosed();
                }
            });
        });
    }
}

void Widget::moveGif()
{
    QPoint currentPos = label.pos();
    QPoint delta = targetPos - currentPos;

    if (delta.manhattanLength() <= 3) {
        LinMovetimer->stop();
        movie->stop();
        movie->setFileName(":/gif/gif/Lin-quidar.gif");
        movie->start();
        label.move(targetPos);
    } else {
        if (targetPos.x() > currentPos.x() + 90) {
            // 向右走
            movie->stop();
            movie->setFileName(":/gif/gif/Lin-conducir.gif");
            movie->start();
        } else if (targetPos.x() < currentPos.x() + 18) {
            // 向左走
            movie->stop();
            movie->setFileName(":/gif/gif/Lin-conducir-izquierda.gif");
            movie->start();
        }

        QVector2D vecDelta(delta);
        QVector2D step = vecDelta.normalized() * 3;
        QPoint newStep(step.toPoint());
        label.move(currentPos + newStep);
    }
}

void Widget::onButtonClicked(QPushButton* button)
{
    QPoint currentPos = label.pos();
    QPoint targetPos;

    if (button == &LilyButton) {
        targetPos = LilyTargetPos;
    } else if (button == &OscarButton) {
        targetPos = OscarTargetPos;
    } else if (button == &FalstaffButton) {
        targetPos = FalstaffTargetPos;
    } else if (button == &DuoButton) {
        targetPos = DuoTargetPos;
    }


    //cuPos = currentPos;
    QPoint distance = currentPos - targetPos;
    if (distance.manhattanLength() <= 100) {
        QDialog *dialog = new QDialog(this);
        if(button == &LilyButton){
            dialog->setWindowTitle("Lily's Challenge");
            dialog->resize(540, 960);
            // 设置背景颜色为黑色
            dialog->setStyleSheet("background-color: rgb(255, 255, 255);");
            lilyChallengeDialog = dialog;
            connect(lilyChallengeDialog, &QDialog::finished, this, &Widget::onLilyDialogClosed);
            dialog->show();
            ChallengeOne();
        }else if (button == &OscarButton) {
            dialog->setWindowTitle("Oscar's Challenge");
            dialog->resize(540, 960);
            dialog->show();
        } else if (button == &FalstaffButton) {
            dialog->setWindowTitle("Falstaff's Challenge");
            dialog->resize(540, 960);
            dialog->show();
        } else if (button == &DuoButton) {
            dialog->setWindowTitle("Duo's Challenge");
            dialog->resize(540, 960);
            dialog->show();
        }
    }
}

void Widget::onLilyDialogClosed()
{
    isHandlingEventsInMainWidget = true;
    // 自动删除所有子对象（包括动画资源）
    lilyChallengeDialog->deleteLater();
    lilyChallengeDialog = nullptr;

    // 重置指针避免野指针
    challengeLabel = nullptr;
    challengeMovie = nullptr;
    currentSentenceLabel = nullptr;
    currentButton = nullptr;


}
